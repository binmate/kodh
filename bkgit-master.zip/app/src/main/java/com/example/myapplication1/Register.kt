package com.example.myapplication1

import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.PersistableBundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class Register : AppCompatActivity() {
    val TAG: String = "Register"
    var isExistBlank = false
    var isPWSame = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.signup)

        val back : TextView = findViewById(R.id.back)
        back.setOnClickListener {                         //돌아가기를 누르면 다시 메인화면으로
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        val btn_register : Button = findViewById(R.id.signupbutton)
        btn_register.setOnClickListener {
            Log.d(TAG, "회원가입 버튼 클릭")

            val id : EditText = findViewById(R.id.signID)
            val pw : EditText = findViewById(R.id.signPW)
            val pw_re : EditText = findViewById(R.id.signPW2) //회원가입 페이지 아이디, 패스워드, 패스워드 확인 선언

            id.text.toString()
            pw.text.toString()
            pw_re.text.toString()

            /*if(id.isEmpty() || pw.isEmpty() || pw_re.isEmpty()) { //유저가 입력 항목을 모두 채우지 않았을 때
                isExistBlank = true
            }
            else {
                if(pw == pw_re) { //패스워드가 같은지 확인
                    isPWSame = true
                }
            }*/
            if(!isExistBlank && isPWSame) {
                val sharedPreference = getSharedPreferences("file name", Context.MODE_PRIVATE)
                val editor = sharedPreference.edit()
                editor.putString("id", id.toString())
                editor.putString("pw", pw.toString())
                editor.apply()

                Toast.makeText(this, "회원가입 성공", Toast.LENGTH_SHORT).show() //회원가입 성공 메세지

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }
            else {
                if(isExistBlank) {
                    dialog("black")
                }
                else if(!isPWSame)
                    dialog("not same")
            }
        }
    }

    fun dialog(type: String) { //회원가입 실패 시 메세지
        val dialog = AlertDialog.Builder(this)

        if(type.equals("blank")) {
            dialog.setTitle("회원가입 실패")
            dialog.setMessage("입력란을 모두 작성해주세요")
        }
        else if(type.equals("not same")) {
            dialog.setTitle("회원가입 실패")
            dialog.setMessage("비밀번호가 다릅니다")
        }

        val dialog_listener = object: DialogInterface.OnClickListener {
            override fun onClick(dialog: DialogInterface?, which: Int) {
                when(which) {
                    DialogInterface.BUTTON_POSITIVE -> Log.d(TAG, "다이얼로그")
                }
            }
        }

        dialog.setPositiveButton("확인", dialog_listener)
        dialog.show()
    }
}
