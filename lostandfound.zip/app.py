from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash
from konlpy.tag import kkma

app = Flask(__name__)
kkma = kkma()
app.secret_key = 'your_secret_key'

# 데이터베이스 초기화
def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        password TEXT NOT NULL
    )
    ''')
    c.execute('''
    CREATE TABLE IF NOT EXISTS lost_items (
        id INTEGER PRIMARY KEY AUTO
        location TEXT NOT NULL,INCREMENT,
        item_name TEXT NOT NULL,
        date TEXT NOT NULL,
        description TEXT NOT NULL
    )
    ''')
    conn.commit()
    conn.close()

init_db()

# 홈 페이지
@app.route('/')
def index():
    return render_template('index.html')

# 로그인 페이지
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('SELECT * FROM users WHERE username = ?', (username,))
        user = c.fetchone()
        conn.close()
        if user and check_password_hash(user[2], password):
            session['username'] = username
            return redirect(url_for('index'))
        else:
            return render_template('login.html', error='Invalid username or password')
    return render_template('login.html')

# 로그아웃
@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

# 분실물 등록 페이지
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        item_name = request.form['item_name']
        location = request.form['location']
        date = request.form['date']
        description = request.form['description']
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('''
        INSERT INTO lost_items (item_name, location, date, description)
        VALUES (?, ?, ?, ?)
        ''', (item_name, location, date, description))
        conn.commit()
        conn.close()
        return redirect(url_for('lost_items'))
    return render_template('register_lost_item.html')

# 분실물 찾기 페이지
@app.route('/lost_items')
def lost_items():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute('SELECT * FROM lost_items')
    items = c.fetchall()
    conn.close()
    return render_template('lost_items.html', items=items)

# 회원가입 페이지
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password, method='sha256')
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute('INSERT INTO users (username, password) VALUES (?, ?, ?)', (username, hashed_password))
        conn.commit()
        conn.close()
        return redirect(url_for('login'))
    return render_template('signup.html')

@app.route('/fetch_lost_items')
def fetch_lost_items():
    # 데이터베이스에서 분실물 등록 내용을 조회하는 로직을 작성합니다.
    # 여기서는 예시로 단순히 데이터베이스에 저장된 모든 분실물을 가져오는 것으로 가정합니다.
    # 실제로는 필요에 따라 적절한 쿼리를 사용하여 데이터를 가져와야 합니다.
    lost_items = [
        {'item_name': '지갑', 'location': '도서관', 'date': '2024-06-01', 'description': '검정색 지갑입니다.'},
        {'item_name': '열쇠', 'location': '주차장', 'date': '2024-06-03', 'description': '은색 열쇠입니다.'},
        # 추가적인 분실물 정보들...
    ]
    return jsonify(lost_items)

@app.route('/chatbot', methods=['POST'])
def chatbot():
    question = request.json.get('message')
    morphs = kkma.morphs(question)
    return jsonify({'response' : morphs})

if __name__ == '__main__':
    app.run(debug=True)
