from flask import Flask, render_template, request, jsonify, redirect, url_for
from konlpy.tag import Kkma

app = Flask(__name__)
kkma = Kkma()

# 분실물 등록 데이터베이스 대신에 예시로 사용할 분실물 리스트
lost_items = []

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        item_name = request.form['item_name']
        location = request.form['location']
        date = request.form['date']
        description = request.form['description']
        lost_items.append({'item_name': item_name, 'location': location, 'date': date, 'description': description})
        return render_template('register_success.html')
    return render_template('register.html')

@app.route('/lost_items')
def lost_items_page():
    return render_template('lost_items.html')

@app.route('/fetch_lost_items')
def fetch_lost_items():
    return jsonify(lost_items)

@app.route('/chatbot', methods=['POST'])
def chatbot():
    question = request.json.get('message')
    morphs = kkma.morphs(question)
    return jsonify({'response': morphs})

@app.route('/chat')
def chat():
    return render_template('chatbot.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # 로그인 로직을 여기에 추가하세요 (예: 데이터베이스와 연동)
        return redirect(url_for('index'))
    return render_template('login.html')

if __name__ == '__main__':
    app.run(debug=True)
