function findItem() {
    const itemName = document.getElementById('item_name').value;
    fetch('/find_item', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ item_name: itemName }),
    })
    .then(response => response.json())
    .then(data => {
        const resultsDiv = document.getElementById('results');
        if (data.message) {
            resultsDiv.innerHTML = `<p>${data.message}</p>`;
        } else {
            let resultsHTML = '<ul>';
            data.forEach(item => {
                resultsHTML += `<li>${item.item_name} - ${item.location} - ${item.date} - ${item.description}</li>`;
            });
            resultsHTML += '</ul>';
            resultsDiv.innerHTML = resultsHTML;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
// 로그인 모달 열기
document.getElementById('loginBtn').addEventListener('click', function() {
    document.getElementById('loginModal').style.display = 'block';
});

// 모달 닫기 버튼
document.querySelector('.close').addEventListener('click', function() {
    document.getElementById('loginModal').style.display = 'none';
});

// 모달 바깥 클릭 시 모달 닫기
window.addEventListener('click', function(event) {
    if (event.target == document.getElementById('loginModal')) {
        document.getElementById('loginModal').style.display = 'none';
    }
});
// 홈 버튼 클릭 시 메인 화면으로 이동
document.getElementById('homeBtn').addEventListener('click', function(event) {
    event.preventDefault();
    // 메인 화면의 URL로 이동
    window.location.href = '/';
});

// 분실물 등록 버튼 클릭 시 등록 페이지로 이동
document.getElementById('registerBtn').addEventListener('click', function(event) {
    event.preventDefault();
    // 분실물 등록 페이지의 URL로 이동
    window.location.href = '/register';
});

function openChat() {
    const chatContainer = document.getElementById('chat-container');
    chatContainer.classList.toggle('hidden');
}

function sendMessage() {
    // sendMessage 함수는 이미 작성한 것을 사용합니다.
}

function sendMessage() {
    const userInput = document.getElementById('user-input').value;
    const chatBox = document.getElementById('chat-box');

    // 사용자가 입력한 메시지를 채팅창에 추가
    chatBox.innerHTML += `<div class="user-message">${userInput}</div>`;

    // 서버로 메시지를 전송하여 답변을 받음
    fetch('/chatbot', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: userInput }),
    })
    .then(response => response.json())
    .then(data => {
        // 서버에서 받은 답변을 채팅창에 추가
        chatBox.innerHTML += `<div class="bot-message">${data.response}</div>`;
    })
    .catch(error => {
        console.error('Error:', error);
    });

    // 입력창 비우기
    document.getElementById('user-input').value = '';
}

function fetchLostItems() {
    fetch('/fetch_lost_items')
    .then(response => response.json())
    .then(data => {
        displayLostItems(data);
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function displayLostItems(items) {
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML += '<div class="bot-message">분실물 목록:</div>';
    items.forEach(item => {
        chatBox.innerHTML += `<div class="bot-message">${item.item_name} - ${item.location} - ${item.date} - ${item.description}</div>`;
    });
}